## SimplyDark
A sharp and simple theme for Discord.

- - -
BetterDiscord Download: [https://betterdiscord.app/theme/SimplyDark](https://betterdiscord.app/Download?id=394)  
Powercord Install: `git clone https://github.com/DiscordStyles/SimplyDark`  
Vencord link: `https://raw.githubusercontent.com/DiscordStyles/SimplyDark/deploy/SimplyDark.theme.css`

- - -

Server Chat
![image](https://i.imgur.com/TATxJ9s.png)

## Contributing

Looking to contribute to SimplyDark? Read the the [contributing.md](https://github.com/DiscordStyles/iPadOS/blob/master/CONTRIBUTING.md) file.

## License

See the [LICENSE](https://github.com/DiscordStyles/SimplyDark/blob/master/LICENSE.md) file for license rights and limitations (MIT).